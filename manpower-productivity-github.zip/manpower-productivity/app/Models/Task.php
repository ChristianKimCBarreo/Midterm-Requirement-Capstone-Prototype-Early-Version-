<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Task extends Model
{
    public const PENDING = 'pending';
    public const IN_PROGRESS = 'in_progress';
    public const SUBMITTED = 'submitted';
    public const APPROVED = 'approved';
    public const REJECTED = 'rejected';

    public const STATUSES = [
        self::PENDING => 'Pending',
        self::IN_PROGRESS => 'In Progress',
        self::SUBMITTED => 'Submitted',
        self::APPROVED => 'Approved',
        self::REJECTED => 'Rejected',
    ];

    protected $fillable = [
        'title',
        'description',
        'assigned_to',
        'created_by',
        'deadline',
        'status',
        'submission_notes',
        'submitted_at',
        'admin_feedback',
    ];

    protected function casts(): array
    {
        return [
            'deadline' => 'date',
            'submitted_at' => 'datetime',
        ];
    }

    public function employee(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function isOverdue(): bool
    {
        return $this->deadline->isPast()
            && ! $this->deadline->isToday()
            && ! in_array($this->status, [self::SUBMITTED, self::APPROVED]);
    }
}
