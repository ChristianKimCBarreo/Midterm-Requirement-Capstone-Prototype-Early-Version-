<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Task;
use App\Models\User;

class EmployeeController extends Controller
{
    public function index()
    {
        $employees = User::where('role', 'employee')
            ->withCount([
                'assignedTasks',
                'assignedTasks as approved_tasks_count' => fn ($q) => $q->where('status', Task::APPROVED),
            ])
            ->orderBy('name')
            ->get();

        return view('admin.employees.index', compact('employees'));
    }
}
