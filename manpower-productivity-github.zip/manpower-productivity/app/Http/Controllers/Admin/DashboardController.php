<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Task;
use App\Models\User;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'employees' => User::where('role', 'employee')->count(),
            'tasks' => Task::count(),
            'awaiting' => Task::where('status', Task::SUBMITTED)->count(),
            'approved' => Task::where('status', Task::APPROVED)->count(),
        ];

        $awaitingReview = Task::with('employee')
            ->where('status', Task::SUBMITTED)
            ->orderBy('submitted_at')
            ->get();

        return view('admin.dashboard', compact('stats', 'awaitingReview'));
    }
}
