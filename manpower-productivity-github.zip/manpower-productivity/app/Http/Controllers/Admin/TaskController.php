<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Task;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class TaskController extends Controller
{
    public function index(Request $request)
    {
        $tasks = Task::with('employee')
            ->when(
                array_key_exists($request->status, Task::STATUSES),
                fn ($query) => $query->where('status', $request->status)
            )
            ->latest()
            ->paginate(10)
            ->withQueryString();

        return view('admin.tasks.index', compact('tasks'));
    }

    public function create()
    {
        return view('admin.tasks.create', ['employees' => $this->employees()]);
    }

    public function store(Request $request)
    {
        $data = $request->validate($this->rules());

        Task::create($data + [
            'created_by' => $request->user()->id,
            'status' => Task::PENDING,
        ]);

        return redirect()->route('admin.tasks.index')->with('success', 'Task created and assigned.');
    }

    public function show(Task $task)
    {
        $task->load(['employee', 'creator']);

        return view('admin.tasks.show', compact('task'));
    }

    public function edit(Task $task)
    {
        return view('admin.tasks.edit', ['task' => $task, 'employees' => $this->employees()]);
    }

    public function update(Request $request, Task $task)
    {
        $task->update($request->validate($this->rules()));

        return redirect()->route('admin.tasks.show', $task)->with('success', 'Task updated.');
    }

    public function destroy(Task $task)
    {
        $task->delete();

        return redirect()->route('admin.tasks.index')->with('success', 'Task deleted.');
    }

    public function review(Request $request, Task $task)
    {
        if ($task->status !== Task::SUBMITTED) {
            return back()->with('error', 'Only submitted tasks can be reviewed.');
        }

        $data = $request->validate([
            'decision' => ['required', Rule::in([Task::APPROVED, Task::REJECTED])],
            'admin_feedback' => ['nullable', 'string', 'max:1000', 'required_if:decision,'.Task::REJECTED],
        ]);

        $task->update([
            'status' => $data['decision'],
            'admin_feedback' => $data['admin_feedback'] ?? null,
        ]);

        return redirect()->route('admin.tasks.show', $task)->with('success', 'Review saved.');
    }

    private function employees()
    {
        return User::where('role', 'employee')->orderBy('name')->get();
    }

    private function rules(): array
    {
        return [
            'title' => ['required', 'string', 'max:255'],
            'description' => ['required', 'string'],
            'assigned_to' => ['required', Rule::exists('users', 'id')->where('role', 'employee')],
            'deadline' => ['required', 'date'],
        ];
    }
}
