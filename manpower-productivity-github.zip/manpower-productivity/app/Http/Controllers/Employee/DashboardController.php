<?php

namespace App\Http\Controllers\Employee;

use App\Http\Controllers\Controller;
use App\Models\Task;

class DashboardController extends Controller
{
    public function index()
    {
        $tasks = Task::where('assigned_to', auth()->id());

        $stats = [
            'total' => (clone $tasks)->count(),
            'active' => (clone $tasks)->whereIn('status', [Task::PENDING, Task::IN_PROGRESS, Task::REJECTED])->count(),
            'submitted' => (clone $tasks)->where('status', Task::SUBMITTED)->count(),
            'approved' => (clone $tasks)->where('status', Task::APPROVED)->count(),
        ];

        $upcoming = (clone $tasks)
            ->whereIn('status', [Task::PENDING, Task::IN_PROGRESS, Task::REJECTED])
            ->orderBy('deadline')
            ->take(5)
            ->get();

        return view('employee.dashboard', compact('stats', 'upcoming'));
    }
}
