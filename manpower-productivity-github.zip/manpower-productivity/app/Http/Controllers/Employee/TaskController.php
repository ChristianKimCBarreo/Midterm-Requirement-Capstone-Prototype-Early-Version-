<?php

namespace App\Http\Controllers\Employee;

use App\Http\Controllers\Controller;
use App\Models\Task;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function index()
    {
        $tasks = Task::where('assigned_to', auth()->id())
            ->orderBy('deadline')
            ->get();

        return view('employee.tasks.index', compact('tasks'));
    }

    public function show(Task $task)
    {
        $this->authorizeOwner($task);

        return view('employee.tasks.show', compact('task'));
    }

    public function start(Task $task)
    {
        $this->authorizeOwner($task);

        if (! in_array($task->status, [Task::PENDING, Task::REJECTED])) {
            return back()->with('error', 'This task cannot be started.');
        }

        $task->update(['status' => Task::IN_PROGRESS]);

        return back()->with('success', 'Task marked as in progress.');
    }

    public function submit(Request $request, Task $task)
    {
        $this->authorizeOwner($task);

        if (! in_array($task->status, [Task::PENDING, Task::IN_PROGRESS, Task::REJECTED])) {
            return back()->with('error', 'This task cannot be submitted.');
        }

        $data = $request->validate([
            'submission_notes' => ['required', 'string', 'max:2000'],
        ]);

        $task->update([
            'submission_notes' => $data['submission_notes'],
            'submitted_at' => now(),
            'status' => Task::SUBMITTED,
            'admin_feedback' => null,
        ]);

        return redirect()->route('employee.tasks.show', $task)->with('success', 'Task submitted for review.');
    }

    private function authorizeOwner(Task $task): void
    {
        abort_unless($task->assigned_to === auth()->id(), 403);
    }
}
