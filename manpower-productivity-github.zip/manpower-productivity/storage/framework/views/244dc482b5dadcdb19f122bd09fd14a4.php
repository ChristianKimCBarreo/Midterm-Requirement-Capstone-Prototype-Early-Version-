<?php $__env->startSection('title', 'Tasks'); ?>
<?php $__env->startSection('heading', 'Task Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4 flex flex-wrap items-center justify-between gap-3">
    <form method="GET" class="flex items-center gap-2">
        <select name="status" onchange="this.form.submit()" class="rounded-lg border-slate-300 text-sm">
            <option value="">All statuses</option>
            <?php $__currentLoopData = \App\Models\Task::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value); ?>" <?php if(request('status') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </form>
    <a href="<?php echo e(route('admin.tasks.create')); ?>" class="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700">New task</a>
</div>

<div class="overflow-x-auto rounded-xl bg-white shadow-sm">
    <table class="min-w-full text-sm">
        <thead class="bg-slate-50 text-left text-slate-500">
            <tr>
                <th class="px-5 py-3 font-medium">Title</th>
                <th class="px-5 py-3 font-medium">Employee</th>
                <th class="px-5 py-3 font-medium">Deadline</th>
                <th class="px-5 py-3 font-medium">Status</th>
                <th class="px-5 py-3"></th>
            </tr>
        </thead>
        <tbody class="divide-y">
            <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-slate-50">
                    <td class="px-5 py-3 font-medium"><?php echo e($task->title); ?></td>
                    <td class="px-5 py-3"><?php echo e($task->employee->name); ?></td>
                    <td class="px-5 py-3 <?php echo e($task->isOverdue() ? 'text-rose-600 font-medium' : ''); ?>"><?php echo e($task->deadline->format('M d, Y')); ?></td>
                    <td class="px-5 py-3"><?php echo $__env->make('partials.status-badge', ['status' => $task->status], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                    <td class="px-5 py-3 text-right whitespace-nowrap">
                        <a href="<?php echo e(route('admin.tasks.show', $task)); ?>" class="text-indigo-600 hover:underline">View</a>
                        <a href="<?php echo e(route('admin.tasks.edit', $task)); ?>" class="ml-3 text-slate-600 hover:underline">Edit</a>
                        <form method="POST" action="<?php echo e(route('admin.tasks.destroy', $task)); ?>" class="inline" onsubmit="return confirm('Delete this task?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="ml-3 text-rose-600 hover:underline">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="px-5 py-8 text-center text-slate-500">No tasks found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="mt-4"><?php echo e($tasks->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\christian kim barreo\Downloads\project-prototype\manpower-productivity\resources\views/admin/tasks/index.blade.php ENDPATH**/ ?>