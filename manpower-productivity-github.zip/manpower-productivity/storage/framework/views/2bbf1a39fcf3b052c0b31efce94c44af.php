<?php $__env->startSection('title', 'New Task'); ?>
<?php $__env->startSection('heading', 'Create Task'); ?>

<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('admin.tasks.store')); ?>" class="max-w-2xl rounded-xl bg-white p-6 shadow-sm">
    <?php echo csrf_field(); ?>
    <?php echo $__env->make('admin.tasks._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="mt-6 flex gap-3">
        <button class="rounded-lg bg-indigo-600 px-5 py-2 text-sm font-medium text-white hover:bg-indigo-700">Assign task</button>
        <a href="<?php echo e(route('admin.tasks.index')); ?>" class="rounded-lg border px-5 py-2 text-sm hover:bg-slate-50">Cancel</a>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\christian kim barreo\Downloads\project-prototype\manpower-productivity\resources\views/admin/tasks/create.blade.php ENDPATH**/ ?>