<?php $__env->startSection('title', 'My Tasks'); ?>
<?php $__env->startSection('heading', 'My Tasks'); ?>

<?php $__env->startSection('content'); ?>
<div class="grid gap-4 md:grid-cols-2">
    <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="<?php echo e(route('employee.tasks.show', $task)); ?>" class="rounded-xl bg-white p-5 shadow-sm transition hover:shadow-md">
            <div class="flex items-start justify-between gap-3">
                <h2 class="font-semibold"><?php echo e($task->title); ?></h2>
                <?php echo $__env->make('partials.status-badge', ['status' => $task->status], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <p class="mt-2 line-clamp-2 text-sm text-slate-600"><?php echo e($task->description); ?></p>
            <p class="mt-3 text-sm <?php echo e($task->isOverdue() ? 'text-rose-600 font-medium' : 'text-slate-500'); ?>">Due <?php echo e($task->deadline->format('M d, Y')); ?></p>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="col-span-full rounded-xl bg-white px-5 py-8 text-center text-sm text-slate-500 shadow-sm">No tasks assigned to you yet.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\christian kim barreo\Downloads\project-prototype\manpower-productivity\resources\views/employee/tasks/index.blade.php ENDPATH**/ ?>