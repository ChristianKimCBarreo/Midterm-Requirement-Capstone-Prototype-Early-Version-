<?php $__env->startSection('title', $task->title); ?>
<?php $__env->startSection('heading', 'Task Details'); ?>

<?php $__env->startSection('content'); ?>
<?php $open = in_array($task->status, ['pending', 'in_progress', 'rejected']); ?>
<div class="max-w-3xl space-y-6">
    <div class="rounded-xl bg-white p-6 shadow-sm">
        <div class="flex items-start justify-between gap-4">
            <h2 class="text-lg font-semibold"><?php echo e($task->title); ?></h2>
            <?php echo $__env->make('partials.status-badge', ['status' => $task->status], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
        <p class="mt-3 whitespace-pre-line text-slate-600"><?php echo e($task->description); ?></p>
        <p class="mt-4 text-sm <?php echo e($task->isOverdue() ? 'text-rose-600 font-medium' : 'text-slate-500'); ?>">Deadline: <?php echo e($task->deadline->format('M d, Y')); ?></p>
    </div>

    <?php if($task->admin_feedback): ?>
        <div class="rounded-xl border border-slate-200 bg-white p-5 text-sm shadow-sm">
            <p class="font-medium">Admin feedback</p>
            <p class="mt-1 text-slate-600"><?php echo e($task->admin_feedback); ?></p>
        </div>
    <?php endif; ?>

    <?php if($task->submission_notes && ! $open): ?>
        <div class="rounded-xl bg-white p-6 shadow-sm">
            <h3 class="font-semibold">Your submission</h3>
            <p class="mt-3 whitespace-pre-line text-slate-600"><?php echo e($task->submission_notes); ?></p>
        </div>
    <?php endif; ?>

    <?php if($open): ?>
        <?php if($task->status !== 'in_progress'): ?>
            <form method="POST" action="<?php echo e(route('employee.tasks.start', $task)); ?>">
                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <button class="rounded-lg bg-blue-600 px-5 py-2 text-sm font-medium text-white hover:bg-blue-700">Start working</button>
            </form>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('employee.tasks.submit', $task)); ?>" class="rounded-xl bg-white p-6 shadow-sm">
            <?php echo csrf_field(); ?>
            <h3 class="font-semibold">Submit completed work</h3>
            <label for="submission_notes" class="mt-3 block text-sm font-medium">Submission notes</label>
            <textarea id="submission_notes" name="submission_notes" rows="4" class="mt-1 block w-full rounded-lg border-slate-300 text-sm"><?php echo e(old('submission_notes', $task->submission_notes)); ?></textarea>
            <?php $__errorArgs = ['submission_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-sm text-rose-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <button class="mt-4 rounded-lg bg-indigo-600 px-5 py-2 text-sm font-medium text-white hover:bg-indigo-700">Submit for review</button>
        </form>
    <?php elseif($task->status === 'submitted'): ?>
        <p class="rounded-xl bg-amber-50 px-5 py-4 text-sm text-amber-800">Waiting for the administrator to review your submission.</p>
    <?php endif; ?>

    <a href="<?php echo e(route('employee.tasks.index')); ?>" class="inline-block text-sm text-indigo-600 hover:underline">&larr; Back to my tasks</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\christian kim barreo\Downloads\project-prototype\manpower-productivity\resources\views/employee/tasks/show.blade.php ENDPATH**/ ?>