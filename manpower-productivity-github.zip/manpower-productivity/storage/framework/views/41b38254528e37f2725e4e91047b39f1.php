<?php
    $styles = [
        'pending' => 'bg-slate-100 text-slate-700',
        'in_progress' => 'bg-blue-100 text-blue-700',
        'submitted' => 'bg-amber-100 text-amber-800',
        'approved' => 'bg-emerald-100 text-emerald-700',
        'rejected' => 'bg-rose-100 text-rose-700',
    ];
?>
<span class="inline-flex rounded-full px-2.5 py-0.5 text-xs font-medium <?php echo e($styles[$status] ?? 'bg-slate-100 text-slate-700'); ?>">
    <?php echo e(\App\Models\Task::STATUSES[$status] ?? $status); ?>

</span>
<?php /**PATH C:\Users\christian kim barreo\Downloads\project-prototype\manpower-productivity\resources\views/partials/status-badge.blade.php ENDPATH**/ ?>