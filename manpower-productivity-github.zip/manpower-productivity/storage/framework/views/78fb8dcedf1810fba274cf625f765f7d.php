<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> - Manpower Productivity</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-slate-100 text-slate-800 antialiased">
<?php
    $user = auth()->user();
    $links = $user->isAdmin()
        ? [
            ['Dashboard', 'admin.dashboard', 'admin.dashboard'],
            ['Tasks', 'admin.tasks.index', 'admin.tasks.*'],
            ['Employees', 'admin.employees.index', 'admin.employees.*'],
        ]
        : [
            ['Dashboard', 'employee.dashboard', 'employee.dashboard'],
            ['My Tasks', 'employee.tasks.index', 'employee.tasks.*'],
        ];
?>
<div class="min-h-screen md:flex">
    <aside class="bg-indigo-900 text-indigo-100 md:w-64 md:min-h-screen md:flex md:flex-col">
        <div class="px-6 py-5 border-b border-indigo-800">
            <p class="text-lg font-semibold text-white">Manpower Productivity</p>
            <p class="text-xs text-indigo-300 mt-1"><?php echo e($user->isAdmin() ? 'Administrator' : 'Employee'); ?> panel</p>
        </div>
        <nav class="flex gap-1 overflow-x-auto px-3 py-3 md:flex-col md:flex-1">
            <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $route, $pattern]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route($route)); ?>"
                   class="whitespace-nowrap rounded-lg px-4 py-2 text-sm font-medium transition <?php echo e(request()->routeIs($pattern) ? 'bg-indigo-700 text-white' : 'hover:bg-indigo-800'); ?>">
                    <?php echo e($label); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>
        <div class="hidden md:block border-t border-indigo-800 px-6 py-4">
            <p class="text-sm font-medium text-white truncate"><?php echo e($user->name); ?></p>
            <p class="text-xs text-indigo-300 truncate mb-3"><?php echo e($user->email); ?></p>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button class="w-full rounded-lg bg-indigo-800 px-4 py-2 text-sm hover:bg-indigo-700">Log out</button>
            </form>
        </div>
    </aside>

    <div class="flex-1 min-w-0">
        <header class="flex items-center justify-between bg-white px-6 py-4 shadow-sm">
            <h1 class="text-xl font-semibold"><?php echo $__env->yieldContent('heading'); ?></h1>
            <form method="POST" action="<?php echo e(route('logout')); ?>" class="md:hidden">
                <?php echo csrf_field(); ?>
                <button class="text-sm text-indigo-700 font-medium">Log out</button>
            </form>
        </header>

        <main class="p-6 max-w-6xl">
            <?php if(session('success')): ?>
                <div class="mb-4 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="mb-4 rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800"><?php echo e(session('error')); ?></div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\Users\christian kim barreo\Downloads\project-prototype\manpower-productivity\resources\views/layouts/panel.blade.php ENDPATH**/ ?>