<?php $__env->startSection('title', 'Employee Dashboard'); ?>
<?php $__env->startSection('heading', 'Welcome, '.auth()->user()->name); ?>

<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-2 gap-4 lg:grid-cols-4">
    <?php $__currentLoopData = [['Total Tasks', $stats['total'], 'text-slate-700'], ['To Do', $stats['active'], 'text-indigo-600'], ['Submitted', $stats['submitted'], 'text-amber-600'], ['Approved', $stats['approved'], 'text-emerald-600']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value, $color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="rounded-xl bg-white p-5 shadow-sm">
            <p class="text-sm text-slate-500"><?php echo e($label); ?></p>
            <p class="mt-2 text-3xl font-bold <?php echo e($color); ?>"><?php echo e($value); ?></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="mt-8 rounded-xl bg-white shadow-sm">
    <div class="border-b px-5 py-4"><h2 class="font-semibold">Upcoming tasks</h2></div>
    <?php $__empty_1 = true; $__currentLoopData = $upcoming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="<?php echo e(route('employee.tasks.show', $task)); ?>" class="flex items-center justify-between gap-3 border-b px-5 py-3 last:border-0 hover:bg-slate-50">
            <div>
                <p class="font-medium"><?php echo e($task->title); ?></p>
                <p class="text-sm <?php echo e($task->isOverdue() ? 'text-rose-600' : 'text-slate-500'); ?>">Due <?php echo e($task->deadline->format('M d, Y')); ?></p>
            </div>
            <?php echo $__env->make('partials.status-badge', ['status' => $task->status], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="px-5 py-8 text-center text-sm text-slate-500">You have no open tasks.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\christian kim barreo\Downloads\project-prototype\manpower-productivity\resources\views/employee/dashboard.blade.php ENDPATH**/ ?>