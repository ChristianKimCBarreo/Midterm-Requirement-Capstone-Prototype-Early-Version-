<?php $__env->startSection('title', 'Admin Dashboard'); ?>
<?php $__env->startSection('heading', 'Welcome, '.auth()->user()->name); ?>

<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-2 gap-4 lg:grid-cols-4">
    <?php $__currentLoopData = [['Employees', $stats['employees'], 'text-indigo-600'], ['Total Tasks', $stats['tasks'], 'text-slate-700'], ['Awaiting Review', $stats['awaiting'], 'text-amber-600'], ['Approved', $stats['approved'], 'text-emerald-600']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value, $color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="rounded-xl bg-white p-5 shadow-sm">
            <p class="text-sm text-slate-500"><?php echo e($label); ?></p>
            <p class="mt-2 text-3xl font-bold <?php echo e($color); ?>"><?php echo e($value); ?></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="mt-8 rounded-xl bg-white shadow-sm">
    <div class="flex items-center justify-between border-b px-5 py-4">
        <h2 class="font-semibold">Tasks awaiting review</h2>
        <a href="<?php echo e(route('admin.tasks.create')); ?>" class="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700">New task</a>
    </div>
    <?php $__empty_1 = true; $__currentLoopData = $awaitingReview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="<?php echo e(route('admin.tasks.show', $task)); ?>" class="flex items-center justify-between border-b px-5 py-3 last:border-0 hover:bg-slate-50">
            <div>
                <p class="font-medium"><?php echo e($task->title); ?></p>
                <p class="text-sm text-slate-500"><?php echo e($task->employee->name); ?> &middot; submitted <?php echo e($task->submitted_at->diffForHumans()); ?></p>
            </div>
            <span class="text-sm font-medium text-indigo-600">Review</span>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="px-5 py-8 text-center text-sm text-slate-500">Nothing to review right now.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\christian kim barreo\Downloads\project-prototype\manpower-productivity\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>