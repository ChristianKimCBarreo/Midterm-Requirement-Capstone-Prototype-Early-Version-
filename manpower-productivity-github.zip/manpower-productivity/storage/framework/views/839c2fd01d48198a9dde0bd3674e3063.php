<?php $__env->startSection('title', $task->title); ?>
<?php $__env->startSection('heading', 'Task Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl space-y-6">
    <div class="rounded-xl bg-white p-6 shadow-sm">
        <div class="flex items-start justify-between gap-4">
            <h2 class="text-lg font-semibold"><?php echo e($task->title); ?></h2>
            <?php echo $__env->make('partials.status-badge', ['status' => $task->status], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
        <p class="mt-3 whitespace-pre-line text-slate-600"><?php echo e($task->description); ?></p>
        <dl class="mt-5 grid gap-4 text-sm sm:grid-cols-3">
            <div><dt class="text-slate-500">Assigned to</dt><dd class="font-medium"><?php echo e($task->employee->name); ?></dd></div>
            <div><dt class="text-slate-500">Created by</dt><dd class="font-medium"><?php echo e($task->creator->name); ?></dd></div>
            <div><dt class="text-slate-500">Deadline</dt><dd class="font-medium <?php echo e($task->isOverdue() ? 'text-rose-600' : ''); ?>"><?php echo e($task->deadline->format('M d, Y')); ?></dd></div>
        </dl>
    </div>

    <?php if($task->submission_notes): ?>
        <div class="rounded-xl bg-white p-6 shadow-sm">
            <h3 class="font-semibold">Submission</h3>
            <p class="mt-1 text-xs text-slate-500">Submitted <?php echo e($task->submitted_at?->format('M d, Y g:i A')); ?></p>
            <p class="mt-3 whitespace-pre-line text-slate-600"><?php echo e($task->submission_notes); ?></p>
            <?php if($task->admin_feedback): ?>
                <div class="mt-4 rounded-lg bg-slate-50 p-4 text-sm">
                    <p class="font-medium">Admin feedback</p>
                    <p class="mt-1 text-slate-600"><?php echo e($task->admin_feedback); ?></p>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if($task->status === \App\Models\Task::SUBMITTED): ?>
        <form method="POST" action="<?php echo e(route('admin.tasks.review', $task)); ?>" class="rounded-xl bg-white p-6 shadow-sm">
            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
            <h3 class="font-semibold">Review submission</h3>
            <label for="admin_feedback" class="mt-3 block text-sm font-medium">Feedback <span class="font-normal text-slate-500">(required when rejecting)</span></label>
            <textarea id="admin_feedback" name="admin_feedback" rows="3" class="mt-1 block w-full rounded-lg border-slate-300 text-sm"><?php echo e(old('admin_feedback')); ?></textarea>
            <?php $__errorArgs = ['admin_feedback'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-sm text-rose-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php $__errorArgs = ['decision'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-sm text-rose-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="mt-4 flex gap-3">
                <button name="decision" value="approved" class="rounded-lg bg-emerald-600 px-5 py-2 text-sm font-medium text-white hover:bg-emerald-700">Approve</button>
                <button name="decision" value="rejected" class="rounded-lg bg-rose-600 px-5 py-2 text-sm font-medium text-white hover:bg-rose-700">Reject</button>
            </div>
        </form>
    <?php endif; ?>

    <a href="<?php echo e(route('admin.tasks.index')); ?>" class="inline-block text-sm text-indigo-600 hover:underline">&larr; Back to tasks</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\christian kim barreo\Downloads\project-prototype\manpower-productivity\resources\views/admin/tasks/show.blade.php ENDPATH**/ ?>