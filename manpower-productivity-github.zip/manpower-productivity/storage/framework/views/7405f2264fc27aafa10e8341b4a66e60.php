<?php $__env->startSection('title', 'Employees'); ?>
<?php $__env->startSection('heading', 'Employees'); ?>

<?php $__env->startSection('content'); ?>
<div class="overflow-x-auto rounded-xl bg-white shadow-sm">
    <table class="min-w-full text-sm">
        <thead class="bg-slate-50 text-left text-slate-500">
            <tr>
                <th class="px-5 py-3 font-medium">Name</th>
                <th class="px-5 py-3 font-medium">Email</th>
                <th class="px-5 py-3 font-medium">Assigned</th>
                <th class="px-5 py-3 font-medium">Approved</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="px-5 py-3 font-medium"><?php echo e($employee->name); ?></td>
                    <td class="px-5 py-3 text-slate-600"><?php echo e($employee->email); ?></td>
                    <td class="px-5 py-3"><?php echo e($employee->assigned_tasks_count); ?></td>
                    <td class="px-5 py-3"><?php echo e($employee->approved_tasks_count); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="px-5 py-8 text-center text-slate-500">No employees yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\christian kim barreo\Downloads\project-prototype\manpower-productivity\resources\views/admin/employees/index.blade.php ENDPATH**/ ?>