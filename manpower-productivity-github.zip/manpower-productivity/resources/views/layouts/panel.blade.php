<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Dashboard') - Manpower Productivity</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-slate-100 text-slate-800 antialiased">
@php
    $user = auth()->user();
    $links = $user->isAdmin()
        ? [
            ['Dashboard', 'admin.dashboard', 'admin.dashboard'],
            ['Tasks', 'admin.tasks.index', 'admin.tasks.*'],
            ['Employees', 'admin.employees.index', 'admin.employees.*'],
        ]
        : [
            ['Dashboard', 'employee.dashboard', 'employee.dashboard'],
            ['My Tasks', 'employee.tasks.index', 'employee.tasks.*'],
        ];
@endphp
<div class="min-h-screen md:flex">
    <aside class="bg-indigo-900 text-indigo-100 md:w-64 md:min-h-screen md:flex md:flex-col">
        <div class="px-6 py-5 border-b border-indigo-800">
            <p class="text-lg font-semibold text-white">Manpower Productivity</p>
            <p class="text-xs text-indigo-300 mt-1">{{ $user->isAdmin() ? 'Administrator' : 'Employee' }} panel</p>
        </div>
        <nav class="flex gap-1 overflow-x-auto px-3 py-3 md:flex-col md:flex-1">
            @foreach ($links as [$label, $route, $pattern])
                <a href="{{ route($route) }}"
                   class="whitespace-nowrap rounded-lg px-4 py-2 text-sm font-medium transition {{ request()->routeIs($pattern) ? 'bg-indigo-700 text-white' : 'hover:bg-indigo-800' }}">
                    {{ $label }}
                </a>
            @endforeach
        </nav>
        <div class="hidden md:block border-t border-indigo-800 px-6 py-4">
            <p class="text-sm font-medium text-white truncate">{{ $user->name }}</p>
            <p class="text-xs text-indigo-300 truncate mb-3">{{ $user->email }}</p>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button class="w-full rounded-lg bg-indigo-800 px-4 py-2 text-sm hover:bg-indigo-700">Log out</button>
            </form>
        </div>
    </aside>

    <div class="flex-1 min-w-0">
        <header class="flex items-center justify-between bg-white px-6 py-4 shadow-sm">
            <h1 class="text-xl font-semibold">@yield('heading')</h1>
            <form method="POST" action="{{ route('logout') }}" class="md:hidden">
                @csrf
                <button class="text-sm text-indigo-700 font-medium">Log out</button>
            </form>
        </header>

        <main class="p-6 max-w-6xl">
            @if (session('success'))
                <div class="mb-4 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">{{ session('success') }}</div>
            @endif
            @if (session('error'))
                <div class="mb-4 rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">{{ session('error') }}</div>
            @endif
            @yield('content')
        </main>
    </div>
</div>
</body>
</html>
