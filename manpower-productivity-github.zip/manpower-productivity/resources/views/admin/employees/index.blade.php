@extends('layouts.panel')
@section('title', 'Employees')
@section('heading', 'Employees')

@section('content')
<div class="overflow-x-auto rounded-xl bg-white shadow-sm">
    <table class="min-w-full text-sm">
        <thead class="bg-slate-50 text-left text-slate-500">
            <tr>
                <th class="px-5 py-3 font-medium">Name</th>
                <th class="px-5 py-3 font-medium">Email</th>
                <th class="px-5 py-3 font-medium">Assigned</th>
                <th class="px-5 py-3 font-medium">Approved</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            @forelse ($employees as $employee)
                <tr>
                    <td class="px-5 py-3 font-medium">{{ $employee->name }}</td>
                    <td class="px-5 py-3 text-slate-600">{{ $employee->email }}</td>
                    <td class="px-5 py-3">{{ $employee->assigned_tasks_count }}</td>
                    <td class="px-5 py-3">{{ $employee->approved_tasks_count }}</td>
                </tr>
            @empty
                <tr><td colspan="4" class="px-5 py-8 text-center text-slate-500">No employees yet.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
