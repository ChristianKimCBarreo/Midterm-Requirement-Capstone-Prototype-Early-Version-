@extends('layouts.panel')
@section('title', 'Admin Dashboard')
@section('heading', 'Welcome, '.auth()->user()->name)

@section('content')
<div class="grid grid-cols-2 gap-4 lg:grid-cols-4">
    @foreach ([['Employees', $stats['employees'], 'text-indigo-600'], ['Total Tasks', $stats['tasks'], 'text-slate-700'], ['Awaiting Review', $stats['awaiting'], 'text-amber-600'], ['Approved', $stats['approved'], 'text-emerald-600']] as [$label, $value, $color])
        <div class="rounded-xl bg-white p-5 shadow-sm">
            <p class="text-sm text-slate-500">{{ $label }}</p>
            <p class="mt-2 text-3xl font-bold {{ $color }}">{{ $value }}</p>
        </div>
    @endforeach
</div>

<div class="mt-8 rounded-xl bg-white shadow-sm">
    <div class="flex items-center justify-between border-b px-5 py-4">
        <h2 class="font-semibold">Tasks awaiting review</h2>
        <a href="{{ route('admin.tasks.create') }}" class="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700">New task</a>
    </div>
    @forelse ($awaitingReview as $task)
        <a href="{{ route('admin.tasks.show', $task) }}" class="flex items-center justify-between border-b px-5 py-3 last:border-0 hover:bg-slate-50">
            <div>
                <p class="font-medium">{{ $task->title }}</p>
                <p class="text-sm text-slate-500">{{ $task->employee->name }} &middot; submitted {{ $task->submitted_at->diffForHumans() }}</p>
            </div>
            <span class="text-sm font-medium text-indigo-600">Review</span>
        </a>
    @empty
        <p class="px-5 py-8 text-center text-sm text-slate-500">Nothing to review right now.</p>
    @endforelse
</div>
@endsection
