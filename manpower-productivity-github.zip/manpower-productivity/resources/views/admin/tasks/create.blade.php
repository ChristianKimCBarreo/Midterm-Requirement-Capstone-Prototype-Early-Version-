@extends('layouts.panel')
@section('title', 'New Task')
@section('heading', 'Create Task')

@section('content')
<form method="POST" action="{{ route('admin.tasks.store') }}" class="max-w-2xl rounded-xl bg-white p-6 shadow-sm">
    @csrf
    @include('admin.tasks._form')
    <div class="mt-6 flex gap-3">
        <button class="rounded-lg bg-indigo-600 px-5 py-2 text-sm font-medium text-white hover:bg-indigo-700">Assign task</button>
        <a href="{{ route('admin.tasks.index') }}" class="rounded-lg border px-5 py-2 text-sm hover:bg-slate-50">Cancel</a>
    </div>
</form>
@endsection
