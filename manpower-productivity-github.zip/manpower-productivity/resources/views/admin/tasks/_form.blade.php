@php $field = 'mt-1 block w-full rounded-lg border-slate-300 text-sm focus:border-indigo-500 focus:ring-indigo-500'; @endphp

<div class="space-y-5">
    <div>
        <label for="title" class="text-sm font-medium">Task title</label>
        <input id="title" name="title" type="text" value="{{ old('title', $task->title ?? '') }}" class="{{ $field }}">
        @error('title') <p class="mt-1 text-sm text-rose-600">{{ $message }}</p> @enderror
    </div>

    <div>
        <label for="description" class="text-sm font-medium">Description</label>
        <textarea id="description" name="description" rows="5" class="{{ $field }}">{{ old('description', $task->description ?? '') }}</textarea>
        @error('description') <p class="mt-1 text-sm text-rose-600">{{ $message }}</p> @enderror
    </div>

    <div class="grid gap-5 sm:grid-cols-2">
        <div>
            <label for="assigned_to" class="text-sm font-medium">Assign to</label>
            <select id="assigned_to" name="assigned_to" class="{{ $field }}">
                <option value="">Select an employee</option>
                @foreach ($employees as $employee)
                    <option value="{{ $employee->id }}" @selected(old('assigned_to', $task->assigned_to ?? '') == $employee->id)>{{ $employee->name }}</option>
                @endforeach
            </select>
            @error('assigned_to') <p class="mt-1 text-sm text-rose-600">{{ $message }}</p> @enderror
        </div>

        <div>
            <label for="deadline" class="text-sm font-medium">Deadline</label>
            <input id="deadline" name="deadline" type="date" value="{{ old('deadline', isset($task) ? $task->deadline->format('Y-m-d') : '') }}" class="{{ $field }}">
            @error('deadline') <p class="mt-1 text-sm text-rose-600">{{ $message }}</p> @enderror
        </div>
    </div>
</div>
