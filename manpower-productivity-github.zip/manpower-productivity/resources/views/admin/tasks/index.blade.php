@extends('layouts.panel')
@section('title', 'Tasks')
@section('heading', 'Task Management')

@section('content')
<div class="mb-4 flex flex-wrap items-center justify-between gap-3">
    <form method="GET" class="flex items-center gap-2">
        <select name="status" onchange="this.form.submit()" class="rounded-lg border-slate-300 text-sm">
            <option value="">All statuses</option>
            @foreach (\App\Models\Task::STATUSES as $value => $label)
                <option value="{{ $value }}" @selected(request('status') === $value)>{{ $label }}</option>
            @endforeach
        </select>
    </form>
    <a href="{{ route('admin.tasks.create') }}" class="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700">New task</a>
</div>

<div class="overflow-x-auto rounded-xl bg-white shadow-sm">
    <table class="min-w-full text-sm">
        <thead class="bg-slate-50 text-left text-slate-500">
            <tr>
                <th class="px-5 py-3 font-medium">Title</th>
                <th class="px-5 py-3 font-medium">Employee</th>
                <th class="px-5 py-3 font-medium">Deadline</th>
                <th class="px-5 py-3 font-medium">Status</th>
                <th class="px-5 py-3"></th>
            </tr>
        </thead>
        <tbody class="divide-y">
            @forelse ($tasks as $task)
                <tr class="hover:bg-slate-50">
                    <td class="px-5 py-3 font-medium">{{ $task->title }}</td>
                    <td class="px-5 py-3">{{ $task->employee->name }}</td>
                    <td class="px-5 py-3 {{ $task->isOverdue() ? 'text-rose-600 font-medium' : '' }}">{{ $task->deadline->format('M d, Y') }}</td>
                    <td class="px-5 py-3">@include('partials.status-badge', ['status' => $task->status])</td>
                    <td class="px-5 py-3 text-right whitespace-nowrap">
                        <a href="{{ route('admin.tasks.show', $task) }}" class="text-indigo-600 hover:underline">View</a>
                        <a href="{{ route('admin.tasks.edit', $task) }}" class="ml-3 text-slate-600 hover:underline">Edit</a>
                        <form method="POST" action="{{ route('admin.tasks.destroy', $task) }}" class="inline" onsubmit="return confirm('Delete this task?')">
                            @csrf @method('DELETE')
                            <button class="ml-3 text-rose-600 hover:underline">Delete</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="5" class="px-5 py-8 text-center text-slate-500">No tasks found.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
<div class="mt-4">{{ $tasks->links() }}</div>
@endsection
