@extends('layouts.panel')
@section('title', $task->title)
@section('heading', 'Task Details')

@section('content')
<div class="max-w-3xl space-y-6">
    <div class="rounded-xl bg-white p-6 shadow-sm">
        <div class="flex items-start justify-between gap-4">
            <h2 class="text-lg font-semibold">{{ $task->title }}</h2>
            @include('partials.status-badge', ['status' => $task->status])
        </div>
        <p class="mt-3 whitespace-pre-line text-slate-600">{{ $task->description }}</p>
        <dl class="mt-5 grid gap-4 text-sm sm:grid-cols-3">
            <div><dt class="text-slate-500">Assigned to</dt><dd class="font-medium">{{ $task->employee->name }}</dd></div>
            <div><dt class="text-slate-500">Created by</dt><dd class="font-medium">{{ $task->creator->name }}</dd></div>
            <div><dt class="text-slate-500">Deadline</dt><dd class="font-medium {{ $task->isOverdue() ? 'text-rose-600' : '' }}">{{ $task->deadline->format('M d, Y') }}</dd></div>
        </dl>
    </div>

    @if ($task->submission_notes)
        <div class="rounded-xl bg-white p-6 shadow-sm">
            <h3 class="font-semibold">Submission</h3>
            <p class="mt-1 text-xs text-slate-500">Submitted {{ $task->submitted_at?->format('M d, Y g:i A') }}</p>
            <p class="mt-3 whitespace-pre-line text-slate-600">{{ $task->submission_notes }}</p>
            @if ($task->admin_feedback)
                <div class="mt-4 rounded-lg bg-slate-50 p-4 text-sm">
                    <p class="font-medium">Admin feedback</p>
                    <p class="mt-1 text-slate-600">{{ $task->admin_feedback }}</p>
                </div>
            @endif
        </div>
    @endif

    @if ($task->status === \App\Models\Task::SUBMITTED)
        <form method="POST" action="{{ route('admin.tasks.review', $task) }}" class="rounded-xl bg-white p-6 shadow-sm">
            @csrf @method('PATCH')
            <h3 class="font-semibold">Review submission</h3>
            <label for="admin_feedback" class="mt-3 block text-sm font-medium">Feedback <span class="font-normal text-slate-500">(required when rejecting)</span></label>
            <textarea id="admin_feedback" name="admin_feedback" rows="3" class="mt-1 block w-full rounded-lg border-slate-300 text-sm">{{ old('admin_feedback') }}</textarea>
            @error('admin_feedback') <p class="mt-1 text-sm text-rose-600">{{ $message }}</p> @enderror
            @error('decision') <p class="mt-1 text-sm text-rose-600">{{ $message }}</p> @enderror
            <div class="mt-4 flex gap-3">
                <button name="decision" value="approved" class="rounded-lg bg-emerald-600 px-5 py-2 text-sm font-medium text-white hover:bg-emerald-700">Approve</button>
                <button name="decision" value="rejected" class="rounded-lg bg-rose-600 px-5 py-2 text-sm font-medium text-white hover:bg-rose-700">Reject</button>
            </div>
        </form>
    @endif

    <a href="{{ route('admin.tasks.index') }}" class="inline-block text-sm text-indigo-600 hover:underline">&larr; Back to tasks</a>
</div>
@endsection
