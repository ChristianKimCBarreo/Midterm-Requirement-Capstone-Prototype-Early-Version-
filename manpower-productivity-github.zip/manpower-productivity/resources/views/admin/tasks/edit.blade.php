@extends('layouts.panel')
@section('title', 'Edit Task')
@section('heading', 'Edit Task')

@section('content')
<form method="POST" action="{{ route('admin.tasks.update', $task) }}" class="max-w-2xl rounded-xl bg-white p-6 shadow-sm">
    @csrf @method('PUT')
    @include('admin.tasks._form')
    <div class="mt-6 flex gap-3">
        <button class="rounded-lg bg-indigo-600 px-5 py-2 text-sm font-medium text-white hover:bg-indigo-700">Save changes</button>
        <a href="{{ route('admin.tasks.show', $task) }}" class="rounded-lg border px-5 py-2 text-sm hover:bg-slate-50">Cancel</a>
    </div>
</form>
@endsection
