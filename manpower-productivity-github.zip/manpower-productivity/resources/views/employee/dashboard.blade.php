@extends('layouts.panel')
@section('title', 'Employee Dashboard')
@section('heading', 'Welcome, '.auth()->user()->name)

@section('content')
<div class="grid grid-cols-2 gap-4 lg:grid-cols-4">
    @foreach ([['Total Tasks', $stats['total'], 'text-slate-700'], ['To Do', $stats['active'], 'text-indigo-600'], ['Submitted', $stats['submitted'], 'text-amber-600'], ['Approved', $stats['approved'], 'text-emerald-600']] as [$label, $value, $color])
        <div class="rounded-xl bg-white p-5 shadow-sm">
            <p class="text-sm text-slate-500">{{ $label }}</p>
            <p class="mt-2 text-3xl font-bold {{ $color }}">{{ $value }}</p>
        </div>
    @endforeach
</div>

<div class="mt-8 rounded-xl bg-white shadow-sm">
    <div class="border-b px-5 py-4"><h2 class="font-semibold">Upcoming tasks</h2></div>
    @forelse ($upcoming as $task)
        <a href="{{ route('employee.tasks.show', $task) }}" class="flex items-center justify-between gap-3 border-b px-5 py-3 last:border-0 hover:bg-slate-50">
            <div>
                <p class="font-medium">{{ $task->title }}</p>
                <p class="text-sm {{ $task->isOverdue() ? 'text-rose-600' : 'text-slate-500' }}">Due {{ $task->deadline->format('M d, Y') }}</p>
            </div>
            @include('partials.status-badge', ['status' => $task->status])
        </a>
    @empty
        <p class="px-5 py-8 text-center text-sm text-slate-500">You have no open tasks.</p>
    @endforelse
</div>
@endsection
