@extends('layouts.panel')
@section('title', 'My Tasks')
@section('heading', 'My Tasks')

@section('content')
<div class="grid gap-4 md:grid-cols-2">
    @forelse ($tasks as $task)
        <a href="{{ route('employee.tasks.show', $task) }}" class="rounded-xl bg-white p-5 shadow-sm transition hover:shadow-md">
            <div class="flex items-start justify-between gap-3">
                <h2 class="font-semibold">{{ $task->title }}</h2>
                @include('partials.status-badge', ['status' => $task->status])
            </div>
            <p class="mt-2 line-clamp-2 text-sm text-slate-600">{{ $task->description }}</p>
            <p class="mt-3 text-sm {{ $task->isOverdue() ? 'text-rose-600 font-medium' : 'text-slate-500' }}">Due {{ $task->deadline->format('M d, Y') }}</p>
        </a>
    @empty
        <p class="col-span-full rounded-xl bg-white px-5 py-8 text-center text-sm text-slate-500 shadow-sm">No tasks assigned to you yet.</p>
    @endforelse
</div>
@endsection
