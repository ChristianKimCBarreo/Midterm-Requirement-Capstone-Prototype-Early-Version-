@extends('layouts.panel')
@section('title', $task->title)
@section('heading', 'Task Details')

@section('content')
@php $open = in_array($task->status, ['pending', 'in_progress', 'rejected']); @endphp
<div class="max-w-3xl space-y-6">
    <div class="rounded-xl bg-white p-6 shadow-sm">
        <div class="flex items-start justify-between gap-4">
            <h2 class="text-lg font-semibold">{{ $task->title }}</h2>
            @include('partials.status-badge', ['status' => $task->status])
        </div>
        <p class="mt-3 whitespace-pre-line text-slate-600">{{ $task->description }}</p>
        <p class="mt-4 text-sm {{ $task->isOverdue() ? 'text-rose-600 font-medium' : 'text-slate-500' }}">Deadline: {{ $task->deadline->format('M d, Y') }}</p>
    </div>

    @if ($task->admin_feedback)
        <div class="rounded-xl border border-slate-200 bg-white p-5 text-sm shadow-sm">
            <p class="font-medium">Admin feedback</p>
            <p class="mt-1 text-slate-600">{{ $task->admin_feedback }}</p>
        </div>
    @endif

    @if ($task->submission_notes && ! $open)
        <div class="rounded-xl bg-white p-6 shadow-sm">
            <h3 class="font-semibold">Your submission</h3>
            <p class="mt-3 whitespace-pre-line text-slate-600">{{ $task->submission_notes }}</p>
        </div>
    @endif

    @if ($open)
        @if ($task->status !== 'in_progress')
            <form method="POST" action="{{ route('employee.tasks.start', $task) }}">
                @csrf @method('PATCH')
                <button class="rounded-lg bg-blue-600 px-5 py-2 text-sm font-medium text-white hover:bg-blue-700">Start working</button>
            </form>
        @endif

        <form method="POST" action="{{ route('employee.tasks.submit', $task) }}" class="rounded-xl bg-white p-6 shadow-sm">
            @csrf
            <h3 class="font-semibold">Submit completed work</h3>
            <label for="submission_notes" class="mt-3 block text-sm font-medium">Submission notes</label>
            <textarea id="submission_notes" name="submission_notes" rows="4" class="mt-1 block w-full rounded-lg border-slate-300 text-sm">{{ old('submission_notes', $task->submission_notes) }}</textarea>
            @error('submission_notes') <p class="mt-1 text-sm text-rose-600">{{ $message }}</p> @enderror
            <button class="mt-4 rounded-lg bg-indigo-600 px-5 py-2 text-sm font-medium text-white hover:bg-indigo-700">Submit for review</button>
        </form>
    @elseif ($task->status === 'submitted')
        <p class="rounded-xl bg-amber-50 px-5 py-4 text-sm text-amber-800">Waiting for the administrator to review your submission.</p>
    @endif

    <a href="{{ route('employee.tasks.index') }}" class="inline-block text-sm text-indigo-600 hover:underline">&larr; Back to my tasks</a>
</div>
@endsection
