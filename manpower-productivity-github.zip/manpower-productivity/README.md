# Manpower Productivity Management System

ITE 116 Laravel Capstone Prototype

## Group Members
- Member 1
- Member 2
- Member 3

## System Description
The Manpower Productivity Management System lets administrators assign tasks to employees and track their progress. Employees view their own tasks, update the status, and submit completed work. Administrators then review each submission and approve or reject it.

## User Roles
**Admin**
- Log in and log out
- View the admin dashboard and the list of employees
- Create, edit, delete and assign tasks to employees
- Monitor the status of all tasks
- Review submitted work and approve or reject it with feedback

**Employee**
- Log in and log out
- View the employee dashboard
- View only their own assigned tasks, with descriptions and deadlines
- Mark a task as in progress
- Submit completed work with notes
- View the approval status and admin feedback

Admin pages are only accessible to admins, and employee pages are only accessible to employees.

## Core Feature
Task assignment and completion management. The admin creates a task and assigns it to an employee, the employee submits the work, and the admin approves or rejects it.

Task statuses: Pending, In Progress, Submitted, Approved, Rejected.

## Demo Accounts
| Role | Email | Password |
|---|---|---|
| Admin | admin@example.com | password123 |
| Employee | employee@example.com | password123 |
| Employee | employee2@example.com | password123 |

For local testing and classroom demonstration only.

## Setup (from a fresh clone)

Requirements: PHP 8.3 or newer, Composer, Node.js with npm, and MySQL.

1. Create an empty MySQL database named `manpower_productivity`.
2. Run the following commands:

```bash
git clone YOUR_GITHUB_REPOSITORY_URL
cd manpower-productivity
composer install
npm install
copy .env.example .env
php artisan key:generate
php artisan migrate --seed
npm run build
php artisan serve
```

On macOS or Linux, use `cp .env.example .env` instead of `copy`.

3. If your MySQL username or password differs from the defaults, edit the `DB_` values in `.env` before running the migration.
4. Open http://127.0.0.1:8000 and log in with a demo account.

## Technologies
Laravel, PHP, MySQL, Blade, Tailwind CSS, Laravel Breeze.
