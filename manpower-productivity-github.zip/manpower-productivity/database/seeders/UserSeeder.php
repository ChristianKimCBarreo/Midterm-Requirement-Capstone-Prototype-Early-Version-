<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        $users = [
            ['Admin User', 'admin@example.com', 'admin'],
            ['Employee One', 'employee@example.com', 'employee'],
            ['Employee Two', 'employee2@example.com', 'employee'],
        ];

        foreach ($users as [$name, $email, $role]) {
            User::updateOrCreate(
                ['email' => $email],
                [
                    'name' => $name,
                    'password' => Hash::make('password123'),
                    'role' => $role,
                    'email_verified_at' => now(),
                ]
            );
        }
    }
}
